let song;         
let button;       
let jumpButton;   
let fft;          

// Preload the music file
function preload() {
  song = loadSound("sample-visualisation.mp3");
}

// Set up the canvas and buttons
function setup() {
  createCanvas(400, 400);  
  fft = new p5.FFT();     
  song.connect(fft);       

  button = createButton('play');      
  button.mousePressed(togglePlaying);  

  jumpButton = createButton('jump');  
  jumpButton.mousePressed(jumpSong);   
}

// Jump to a random position in the song
function jumpSong() {
  let len = song.duration();  // Get the total duration of the song
  let t = random(len);        // Generate a random time point
  console.log(t);
  song.jump(t);               // Jump to the random time point
}

// Toggle between playing and pausing the song
function togglePlaying() {
  if (!song.isPlaying()) {
    song.play();           // Play the song
    song.setVolume(0.3);   
    button.html('pause');  
  } else {
    song.pause();          
    button.html('play');   
  }
}

// Drawing function
function draw() {
  if (getAudioContext().state !== 'running') {
    background(220);
    text('click the "play" button to get some sound!', 80, 190, width - 20);
    text('click the "jump" button to make sound random!', 60, 210, width - 20);
    return;
  }

  background(0);             // Set background color to black
  let spectrum = fft.analyze();  // Analyze the audio and return an array of spectrum values

  let radius = 150;
  let centerX = width / 2;
  let centerY = height / 2;

  let bands = spectrum.length / 7;  // Divide the spectrum into 7 parts
  let colors = [
    color(255, 0, 0),    // Red
    color(255, 165, 0),  // Orange
    color(255, 255, 0),  // Yellow
    color(0, 255, 0),    // Green
    color(0, 255, 255),  // Cyan
    color(0, 0, 255),    // Blue
    color(148, 0, 211)   // Purple
  ];

  noFill();
  strokeWeight(3);

  // Draw the spectrum
  for (let j = 0; j < 7; j++) {
    stroke(colors[j]);     // Set stroke color
    beginShape();           // Start drawing a shape
    for (let i = 0; i < bands; i++) {
      let index = int(i + j * bands);
      let angle = map(index, 0, spectrum.length, -PI, PI);
      let h = map(spectrum[index], 0, 255, 0, radius);
      let x = centerX + (radius - h) * cos(angle);
      let y = centerY + (radius - h) * sin(angle);
      vertex(x, y);         // Draw a point
    }
    endShape();             // End drawing the shape
  }

  // Calculate and draw the spectral centroid
  let spectralCentroid = fft.getCentroid();
  let nyquist = 22050;
  let mean_freq_index = spectralCentroid / (nyquist / spectrum.length);
  let centroidplot = map(log(mean_freq_index), 0, log(spectrum.length), -PI, PI);
  let x = centerX + (radius + 10) * cos(centroidplot);
  let y = centerY + (radius + 10) * sin(centroidplot);
  
  stroke(255);
  strokeWeight(2);
  line(centerX, centerY, x, y);  // Draw a line pointing to the spectral centroid
  
  noStroke();
  fill(255);
  textSize(16);
  text('Centroid: ' + round(spectralCentroid) + ' Hz', 10, 20);  // Display the frequency of the spectral centroid
}
